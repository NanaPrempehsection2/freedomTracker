const bcryptjs = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const generateToken=require("../config/generateToken")
//Register user
const registerUser= async (req,res)=>{
  

  try {
    const {username,email,password}=req.body
    const existingUser= await User.findOne({username})
    if(existingUser){
      return res.status(400).json({error: "Username is taken"})
    }
    const existingEmail=await User.findOne({email})
    if(existingEmail){
      return res.status(400).json({error: "Email is taken"})
    }
    const salt = await bcrypt.genSalt(10)
    const hashedPassword= await bcrypt.hash(password,salt)
    const newUser= new User({username,email,password})
    if(newUser){
      generateToken(newUser._id,res)
      await newUser.save()

      res.status(201).json({
        _id:newUser._id,
        username:newUser.username,
        email:newUser.email
      })
    }else{
      res.status(400).json({error:"Invalid User data"})
    }
    
  } catch (error) {
    console.log("Error during registration",error);
    if(error===11000){
      return res.status(400).json({message:"Email already registered"})
    }
    res.status(500).json({message:"server error"})
    
  }
}


// const registerUser = async (req, res) => {
//   const { email, password } = req.body;

//   try {
//     const existingUser = await User.findOne({ email });
//     if (existingUser) {
//       return res.status(400).json({ message: 'Email is already registered' });
//     }

//     const hashedPassword = await bcrypt.hash(password, 10);
//     const newUser = new User({ email, password: hashedPassword });

//     const savedUser = await newUser.save();
//     console.log('Saved User:', savedUser);

//     const token = jwt.sign({ id: User._id }, process.env.JWT_SECRET, { expiresIn: '24h' });
//     console.log('JWT generated:', token);

//     res.status(201).json({ token });
//   } catch (err) {
//     console.error('Error during registration:', err);
//     res.status(500).json({ message: 'Server error' });
//   }
// };

//Login
const loginUser = async (req, res) => {
  const { email, password } = req.body;

  try {
      let user = await User.findOne({ email });

      if (!user) {
          return res.status(400).json({ message: 'Invalid Credentials' });
      }

      const isMatch = await bcryptjs.compare(password, user.password);

      if (!isMatch) {
          return res.status(400).json({ message: 'Invalid Credentials' });
      }
    generateToken(user._id,res)
    res.status(200).json({
      success:true,
      user:{
        ...user._doc,
        password: ""
      }
    })

    
  } catch (error) {
    console.log("Error in login controller", error.message)
    res.status(500).json({message:"server error"})
  }
}


// const loginUser = async (req, res) => {
  
//   const { email, password } = req.body;
//   try {
//     console.log('Request received for login:', req.body);

//     const user = await User.findOne({ email });
//     if (!user) {
//       console.log('Invalid email or password');
//       return res.status(400).json({ message: 'Invalid email or password' });
//     }

//     const isMatch = await bcrypt.compare(password, user.password);
//     if (!isMatch) {
//       console.log('Invalid email or password');
//       return res.status(400).json({ message: 'Invalid email or password' });
//     }

//     const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
//     console.log('JWT generated for login');

//     res.json({ token, message: 'Login successful' });
//   } catch (err) {
//     console.error('Error during login:', err.message);
//     res.status(500).json({ message: 'Server error' });
//   }
// };

module.exports = { registerUser, loginUser };



