const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const{registerUser,loginUser} = require("../controllers/userController")

const router = express.Router();

router.post("/register",registerUser)
router.post("/login",loginUser)

// //Register 
// router.post('/register', async (req, res) => {
//   const { email, password } = req.body;

//   try {
//     //validate if user exists
//     if (!email || !password) {
//       return res.status(400).json({ message: 'Email and password are required.' });
//     }

//     const existingUser = await User.findOne({ email });
//     if (existingUser) {
//       return res.status(400).json({ message: 'Email is already registered' });
//     }

//     const hashedPassword = await bcrypt.hash(password, 6);

//     const newUser = new User({
//       email,
//       password: hashedPassword,
//     });

//     await newUser.save();

//     const token = jwt.sign({ userId: newUser._id }, process.env.JWT_SECRET || 'fallbackSecret', { expiresIn: '1h' });

//     res.status(201).json({ token });
//   } catch (err) {
//     console.error('Error during registration:', err);
//   //Handle duplicate keys 
//   if(err.code===11000){
//     return res.status(409).json({message: "Email already exists"})
//   }
//     res.status(500).json({ message: 'Server error' });
//   }
// });


module.exports = router;
